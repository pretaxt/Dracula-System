# 推送到 GitHub · 简化版

## 一次性准备

### 1. 配置 git 身份(只做一次)

```bash
git config --global user.name "你的名字"
git config --global user.email "你的邮箱@example.com"
```

### 2. 关闭 Copilot 训练(强烈建议)

打开 https://github.com/settings/copilot/features → Privacy → 关闭 "Allow GitHub to use my data for AI model training"

---

## 推送步骤

### Step 1:在 GitHub 创建仓库

打开 https://github.com/new

- **Repository name**:`fundflow`
- **Visibility**:**Private** ⚠️
- **Initialize**:全部不勾(README、.gitignore、LICENSE 都不要)

点击 **Create repository**

### Step 2:解压本地

把 `fundflow.zip` 解压到你想存代码的地方,例如:

```bash
cd ~/projects
unzip ~/Downloads/fundflow.zip
cd fundflow
```

### Step 3:连接远程并 push

```bash
# 替换 <your-username> 为你的 GitHub 用户名

# SSH 方式(推荐):
git remote add origin git@github.com:<your-username>/fundflow.git

# 或 HTTPS 方式:
# git remote add origin https://github.com/<your-username>/fundflow.git

git push -u origin main
```

如果是第一次用 SSH,先按提示生成 key 并加到 GitHub:https://docs.github.com/en/authentication/connecting-to-github-with-ssh

如果用 HTTPS,会要求输入用户名 + Personal Access Token(不是密码):
- 创建 Token:https://github.com/settings/tokens/new?scopes=repo
- 勾选 `repo`,生成后复制粘贴

---

## 日常工作流

```bash
cd ~/projects/fundflow

# 拉取最新
git pull

# 改完代码后
git status              # 看看改了什么
git diff                # 详细对比
git add .               # 全部加入
git commit -m "feat: add X feature"
git push
```

### Commit message 风格

```
feat: 新功能
fix: 修 bug
docs: 文档
refactor: 重构
test: 测试
chore: 杂项
```

---

## 我下次给你新文档时

我会在沙箱里直接给你单个 markdown 文件,你下载后:

```bash
cd ~/projects/fundflow
# 把新文件放到对应目录,例如 docs/02_strategy_funding_rate.md
git add docs/
git commit -m "docs: add funding rate strategy design"
git push
```

---

## 不小心 commit 了 API key 怎么办

```bash
# 1. 立即去交易所撤销该 key

# 2. 如果还没 push:
git reset --soft HEAD~1
# 把 key 移到 .env,确认它在 .gitignore 里
git add .
git commit -m "..."

# 3. 如果已经 push 了,用 BFG 清除历史:
# https://rtyley.github.io/bfg-repo-cleaner/
```

---

## ✅ 完成后 checklist

- [ ] GitHub 上 `fundflow` 仓库可见
- [ ] 是 **Private**
- [ ] 文件已上传
- [ ] `.env` 没被推送(GitHub 上看不到 .env 文件)
- [ ] README 在仓库主页正常显示
- [ ] Copilot 训练数据收集已关闭

完成后告诉我,我开始写第二份设计文档(资金费率套利策略)。
